﻿namespace RoleBasedAppAccess.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RoleBasedAppAccessModelsApplicationDbContext : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ClientAddresses",
                c => new
                    {
                        cAddressID = c.Int(nullable: false, identity: true),
                        cAddress = c.String(),
                        cPIN = c.Int(nullable: false),
                        City = c.String(),
                        cID = c.Int(nullable: false),
                        Client_cID = c.Long(),
                    })
                .PrimaryKey(t => t.cAddressID)
                .ForeignKey("dbo.Clients", t => t.Client_cID)
                .Index(t => t.Client_cID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ClientAddresses", "Client_cID", "dbo.Clients");
            DropIndex("dbo.ClientAddresses", new[] { "Client_cID" });
            DropTable("dbo.ClientAddresses");
        }
    }
}
