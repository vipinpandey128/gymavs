﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace RoleBasedAppAccess.Models
{
    public class ClientAddress
    {
        [Key]
        public int cAddressID { get; set; }
        public string cAddress { get; set; }
        public int cPIN { get; set; }
        public string City { get; set; }
        public int cID { get; set; }
        public virtual Client Client { get; set; }

    }
}