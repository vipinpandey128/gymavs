﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace RoleBasedAppAccess.Models
{
    public class Days
    {
        [Key]
        public int dID { get; set; }

        [Display(Name ="Days Name")]
        public string dName { get; set; }

        public bool dStatus { get; set; } = true;
    }
}