﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace RoleBasedAppAccess.Models
{
    public class Client
    {
        [Key]
        public long cID { get; set; }

        [Display(Name ="Client Name")]
        public string cName { get; set; }

        [Display(Name = "Client Gender")]
        public string cGen { get; set; }
        public bool cStatus { get; set; } = true;
        public DateTime cCreatedDate { get; set; } = DateTime.Now;
        
    }
}