﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace RoleBasedAppAccess.Models
{
    public class Reciept
    {
        [Key]
        public long rID { get; set; }
        public int MyProperty { get; set; }
    }
}